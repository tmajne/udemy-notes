WYJĄTKI

- omówione w kursie